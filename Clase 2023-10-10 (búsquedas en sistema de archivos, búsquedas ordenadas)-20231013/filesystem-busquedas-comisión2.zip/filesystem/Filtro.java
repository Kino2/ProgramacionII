package filesystem;

public abstract class Filtro {
    public abstract boolean cumple(Archivo dado);
}
