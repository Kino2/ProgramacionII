package parcialito4;

public abstract class Filtro {
    public abstract boolean cumple(Documento doc);
}
