package FileSystem;

public interface Buscador {

    boolean cumple(Archivo archivo);
}
